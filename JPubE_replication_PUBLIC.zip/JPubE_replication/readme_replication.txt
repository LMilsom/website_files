README replication of Spatial Inequality of Opportunity in West Africa, Luke Heath Milsom, 2023 
Paper link: https://www.sciencedirect.com/science/article/pii/S0047272723001263

- The contents of this folder replicates all analysis in the main text 
- Instructions for replication 
	1- Download raw data from IPUMS. The data is free and publically accessable. However, to access the raw data you must create an account and download it 
	onto your own machine from https://international.ipums.org/international/ 
	2- Open "master_dofile" and change the file path to where this folder is located
	3- Run "master_dofile" all analysis should now one-click replicate

If you encounter any issues, spot typos/ mistakes, would like to see replication code for the analysis in the appendix, 
or would just like to discuss this or similar work please contact me using the email address on my website https://www.lukemilsom.com 